package com.splatage.wild_economy.exchange.repository.mysql;

import com.splatage.wild_economy.exchange.domain.ItemKey;
import com.splatage.wild_economy.exchange.repository.ExchangeStockRepository;
import com.splatage.wild_economy.persistence.DatabaseProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

public final class MysqlExchangeStockRepository implements ExchangeStockRepository {

    private final DatabaseProvider databaseProvider;
    private final String exchangeStockTableName;

    public MysqlExchangeStockRepository(final DatabaseProvider databaseProvider, final String exchangeTablePrefix) {
        this.databaseProvider = Objects.requireNonNull(databaseProvider, "databaseProvider");
        this.exchangeStockTableName = Objects.requireNonNull(exchangeTablePrefix, "exchangeTablePrefix") + "exchange_stock";
    }

    @Override
    public long getStock(final ItemKey itemKey) {
        final String sql = "SELECT stock_count FROM " + this.exchangeStockTableName + " WHERE item_key = ?";
        try (
            Connection connection = this.databaseProvider.getConnection();
            PreparedStatement statement = connection.prepareStatement(sql)
        ) {
            statement.setString(1, itemKey.value());
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getLong("stock_count");
                }
                return 0L;
            }
        } catch (final SQLException exception) {
            throw new IllegalStateException("Failed to load stock for " + itemKey.value(), exception);
        }
    }

    @Override
    public Map<ItemKey, Long> getStocks(final Iterable<ItemKey> itemKeys) {
        final Map<ItemKey, Long> result = new LinkedHashMap<>();
        for (final ItemKey itemKey : itemKeys) {
            result.put(itemKey, this.getStock(itemKey));
        }
        return result;
    }

    @Override
    public Map<ItemKey, Long> loadAllStocks() {
        final String sql = "SELECT item_key, stock_count FROM " + this.exchangeStockTableName;
        final Map<ItemKey, Long> result = new LinkedHashMap<>();
        try (
            Connection connection = this.databaseProvider.getConnection();
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery()
        ) {
            while (resultSet.next()) {
                result.put(new ItemKey(resultSet.getString("item_key")), resultSet.getLong("stock_count"));
            }
            return result;
        } catch (final SQLException exception) {
            throw new IllegalStateException("Failed to load exchange stock cache", exception);
        }
    }

    @Override
    public void incrementStock(final ItemKey itemKey, final int amount) {
        if (amount <= 0) {
            return;
        }
        this.changeStockAtomic(itemKey, amount);
    }

    @Override
    public void decrementStock(final ItemKey itemKey, final int amount) {
        if (amount <= 0) {
            return;
        }
        this.changeStockAtomic(itemKey, -amount);
    }

    @Override
    public void setStock(final ItemKey itemKey, final long stock) {
        this.flushStocks(Map.of(itemKey, stock));
    }

    @Override
    public void flushStocks(final Map<ItemKey, Long> stockByItemKey) {
        if (stockByItemKey.isEmpty()) {
            return;
        }

        final String sql = """
            INSERT INTO %s (item_key, stock_count, updated_at)
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE
                stock_count = VALUES(stock_count),
                updated_at = VALUES(updated_at)
            """.formatted(this.exchangeStockTableName);

        try (Connection connection = this.databaseProvider.getConnection()) {
            connection.setAutoCommit(false);
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                final long updatedAt = Instant.now().getEpochSecond();
                for (final Map.Entry<ItemKey, Long> entry : stockByItemKey.entrySet()) {
                    statement.setString(1, entry.getKey().value());
                    statement.setLong(2, Math.max(0L, entry.getValue()));
                    statement.setLong(3, updatedAt);
                    statement.addBatch();
                }
                statement.executeBatch();
                connection.commit();
            } catch (final SQLException exception) {
                connection.rollback();
                throw exception;
            }
        } catch (final SQLException exception) {
            throw new IllegalStateException("Failed to batch flush exchange stock", exception);
        }
    }

    private void changeStockAtomic(final ItemKey itemKey, final int delta) {
        final String insertSql = "INSERT IGNORE INTO " + this.exchangeStockTableName + " (item_key, stock_count, updated_at) VALUES (?, ?, ?)";
        final String updateSql = "UPDATE " + this.exchangeStockTableName + " SET stock_count = GREATEST(0, stock_count + ?), updated_at = ? WHERE item_key = ?";

        try (Connection connection = this.databaseProvider.getConnection()) {
            connection.setAutoCommit(false);
            try (
                PreparedStatement insertStatement = connection.prepareStatement(insertSql);
                PreparedStatement updateStatement = connection.prepareStatement(updateSql)
            ) {
                final long updatedAt = Instant.now().getEpochSecond();

                insertStatement.setString(1, itemKey.value());
                insertStatement.setLong(2, 0L);
                insertStatement.setLong(3, updatedAt);
                insertStatement.executeUpdate();

                updateStatement.setInt(1, delta);
                updateStatement.setLong(2, updatedAt);
                updateStatement.setString(3, itemKey.value());
                updateStatement.executeUpdate();

                connection.commit();
            } catch (final SQLException exception) {
                connection.rollback();
                throw exception;
            }
        } catch (final SQLException exception) {
            throw new IllegalStateException("Failed to atomically change stock for " + itemKey.value(), exception);
        }
    }
}
