package com.splatage.wild_economy.gui;

public final class MenuText {
}
